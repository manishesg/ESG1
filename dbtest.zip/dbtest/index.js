const sql = require('mssql');

const config = {
  user: '',
  password: '',
  server: '',
  database: '',
  options: {
    //encrypt: true,
    //trustServerCertificate: true
  }
  port :
};

async function connectAndQuery() {
  try {
    // Connect to the database
    await sql.connect(config);
    console.log('Connected to the database');

    // Run a sample query
    const result = await sql.query`SELECT 1+2 AS solution`;
    console.log('Query result:', result.recordset);
  } catch (err) {
    console.error('Error:', err);
  } finally {
    // Close the connection
    await sql.close();
    console.log('Connection closed');
  }
}

connectAndQuery();