import{b as a}from"./chunk-XKVPRXWO.js";import"./chunk-VWOTNI2A.js";import"./chunk-A5BBRH6I.js";import"./chunk-UESSH4A2.js";import"./chunk-AGUGUWZC.js";export{a as ModulesRoutingModule};
